"""Independent scoped handoff verifier. Python standard library; no network.
Place beside the audit CSV/JSON files. Optional --materialize restores exact
transported bytes under originals/; this is not reconstruction of missing data.
"""
from pathlib import Path
import base64,collections,csv,datetime,gzip,hashlib,io,json,sys
P=Path(__file__).resolve().parent
checks=[]
def ck(label,ok):
 if not ok:raise AssertionError(label)
 checks.append(label)
def sha(b):return hashlib.sha256(b).hexdigest()
def readcsv(b):return list(csv.DictReader(io.StringIO(b.decode('utf-8-sig'))))
def jfile(name):return json.loads((P/name).read_text(encoding='utf-8'))
def maxflow(edges,sources,target):
 names=sorted({e[k]for e in edges for k in ['from','to']}|{n for n,c in sources}|{'SUPER',target});ix={n:i for i,n in enumerate(names)};g=[[]for n in names]
 def add(a,b,c):
  u,v=ix[a],ix[b];g[u].append([v,c,len(g[v])]);g[v].append([u,0,len(g[u])-1])
 for e in edges:add(e['from'],e['to'],int(e['wei']))
 for n,c in sources:add('SUPER',n,c)
 start,end=ix['SUPER'],ix[target];total=0
 while True:
  level=[-1]*len(g);level[start]=0;q=collections.deque([start])
  while q:
   u=q.popleft()
   for v,c,r in g[u]:
    if c and level[v]<0:level[v]=level[u]+1;q.append(v)
  if level[end]<0:return total
  pos=[0]*len(g)
  def send(u,n):
   if u==end:return n
   while pos[u]<len(g[u]):
    e=g[u][pos[u]];v,c,r=e
    if c and level[v]==level[u]+1:
     f=send(v,min(n,c))
     if f:e[1]-=f;g[v][r][1]+=f;return f
    pos[u]+=1
   return 0
  while True:
   f=send(start,10**100)
   if not f:break
   total+=f

def main():
 allowed={'--materialize'};ck('Known command options',set(sys.argv[1:])<=allowed)
 manifest_bytes=(P/'MANIFEST_SHA256.csv').read_bytes();ck('Detached scoped manifest hash',sha(manifest_bytes)==(P/'MANIFEST_SHA256.txt').read_text().split()[0])
 manifest=readcsv(manifest_bytes)
 for row in manifest:
  path=(P/row['file']).resolve();ck('Manifest path stays in audit folder',path.is_relative_to(P.resolve()))
  b=path.read_bytes();ck('Download integrity '+row['file'],len(b)==int(row['bytes'])and sha(b)==row['sha256'])
 originals={};parts=jfile('TRANSPORT_PARTS.json')
 for part in parts:
  b=(P/part['file']).read_bytes();ck('Part SHA '+part['file'],sha(b)==part['sha256']and len(b)==part['bytes']and len(b)<10_000_000)
  records=json.loads(b)['records'];ck('Part record count '+part['file'],len(records)==part['record_count'])
  for item in records:
   name=item['path'];target=(P/name).resolve();ck('Source path safe',name.startswith('originals/')and target.is_relative_to(P.resolve())and target.is_relative_to((P/'originals').resolve()))
   b=base64.b64decode(item['original_bytes_base64'],validate=True);ck('Exact transported source bytes '+name,len(b)==item['bytes']and sha(b)==item['sha256']and name not in originals)
   decoded=gzip.decompress(b)if item['stored_encoding']=='gzip'else b
   if 'decoded_json'in item:ck('Readable JSON agrees with transported bytes '+name,json.loads(decoded)==item['decoded_json'])
   else:ck('Readable text agrees with transported bytes '+name,decoded.decode('utf-8')==item['text_utf8'])
   originals[name]=b
   if '--materialize'in sys.argv:
    if target.exists():ck('Existing source is unchanged '+name,target.read_bytes()==b)
    else:target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 def data(name):
  b=originals[name];return json.loads(gzip.decompress(b)if name.endswith('.gz')else b)
 def e01(name):return 'originals/release/evidence/E01/'+name
 mapping=readcsv((P/'SOURCE_FILE_INDEX.csv').read_bytes())
 for row in mapping:
  b=originals[row['audit_file']];ck('Selected source mapping '+row['logical_source_path'],sha(b)==row['audit_sha256']and len(b)==int(row['audit_bytes']))
  if row['release_export_sha256']:ck('Published export hash '+row['logical_source_path'],sha(b)==row['release_export_sha256'])
 metadata=jfile('ORIGINAL_METADATA_PARTS.json');full_index=None;full_manifest=None
 for x in metadata:
  chunks=[(P/n).read_bytes()for n in x['parts']];header=chunks[0].splitlines(keepends=True)[0]
  ck('Original metadata part headers '+x['original_release_file'],all(c.startswith(header)for c in chunks))
  b=header+b''.join(c[len(header):]for c in chunks);ck('Original metadata reassembly '+x['original_release_file'],len(b)==x['original_bytes']and sha(b)==x['original_sha256'])
  if x['original_release_file']=='evidence/SOURCE_FILE_INDEX.csv':full_index=readcsv(b)
  if x['original_release_file']=='MANIFEST_SHA256.csv':full_manifest=readcsv(b)
 original_hashes={x['file']:x['sha256']for x in full_manifest};e01_index=[x for x in full_index if x['source_group']=='E01']
 for x in e01_index:
  b=originals['originals/release/'+x['export_file']];ck('Every original E01 logical reference '+x['logical_source_path'],sha(b)==x['export_sha256']==original_hashes[x['export_file']])
 # Reconcile every payout against the exact two retained receipt logs.
 tax=readcsv((P/'TAX_RECEIPTS.csv').read_bytes());table=readcsv(originals[e01('tax_distributions.csv')]);ck('All original tax rows retained',len(tax)==len(table)==1934)
 controller='0x0c6f72f394e968ee80c94727c381dada5fdcfce6';platform='0x8a08d98cbb218fceb318ecf3abc1ba43d8a7ab0e';splitter='0x51db4cc6c47dd545b2328704ee5ca359c98f6f02';sums=[0,0,0];daily=collections.defaultdict(lambda:[0,0,0,0]);stamp_count=0
 for out,old in zip(tax,table):
  h=old['hash'];rec=data(e01('tax_receipts/'+h+'.json.gz'))['result'];selected={}
  for i,l in enumerate(rec['logs']):
   if l['address'].lower()==splitter and len(l['data'])==130:
    a='0x'+l['data'][26:66]
    if a in [controller,platform]:ck('Unique relevant payout log '+h+a,a not in selected);selected[a]=(i,l)
  ck('Both beneficiary logs '+h,set(selected)=={controller,platform});cj,cl=selected[controller];pj,pl=selected[platform]
  c,p,g=[int(old[k])for k in ['controller_wei','platform_wei','gross_wei']]
  ck('Primary tax receipt identity '+h,rec['status']=='0x1'and rec['transactionHash']==out['transaction_hash']==h and int(rec['blockNumber'],16)==int(old['block'])==int(out['block_number']))
  ck('Tax log indices '+h,int(cl['logIndex'],16)==int(out['log_index'])==int(out['beneficiary_log_index'])and int(pl['logIndex'],16)==int(out['platform_log_index']))
  ck('Exact primary payout arithmetic '+h,int(cl['data'][66:],16)==c==int(out['beneficiary_amount_wei'])and int(pl['data'][66:],16)==p==int(out['platform_amount_wei'])and c+p==g==int(out['gross_amount_wei'])and c==g*9000//10000)
  ck('Retained time and source references '+h,out['timestamp_utc']==old['utc']and out['timestamp_unix']==old['timestamp']and out['beneficiary_source_reference'].endswith('/'+str(cj))and out['platform_source_reference'].endswith('/'+str(pj)))
  stamps=[int(l['blockTimestamp'],16)for _,l in selected.values()if l.get('blockTimestamp')]
  if stamps:ck('Retained primary log time '+h,all(t==int(old['timestamp'])for t in stamps));stamp_count+=1
  sums=[a+b for a,b in zip(sums,[c,p,g])];v=daily[old['utc'][:10]];v[0]+=1;v[1]+=c;v[2]+=p;v[3]+=g
 summary=jfile('TAX_SUMMARY.json');ck('Tax computed totals equal supplied summary',sums==[int(summary[k])for k in ['beneficiary_total_wei','platform_total_wei','gross_total_wei']])
 ck('Tax distinct hashes and chronology',len({r['transaction_hash']for r in tax})==1934 and [int(t['timestamp'])for t in table]==sorted(int(t['timestamp'])for t in table))
 ck('Timestamp coverage reported accurately',stamp_count==summary['reconciliation']['receipt_log_timestamp_matches'])
 for cp in summary['chronological_checkpoints']:
  n=cp['after_distribution_count'];expected=[sum(int(x[k])for x in table[:n])for k in ['controller_wei','platform_wei','gross_wei']];ck('Tax chronology checkpoint '+str(n),expected==[int(cp[k])for k in ['beneficiary_total_wei','platform_total_wei','gross_total_wei']]and cp['transaction_hash']==table[n-1]['hash'])
 daily_out=readcsv((P/'TAX_DAILY_CHECKPOINTS.csv').read_bytes());ck('All active payout days retained',len(daily_out)==len(daily))
 for day in daily_out:ck('Daily exact sums '+day['utc_date'],daily[day['utc_date']]==[int(day[k])for k in ['payout_count','beneficiary_wei','platform_wei','gross_wei']])
 # Recompute the time-expanded graph, source capacities, and conditional lower bound.
 graph=data(e01('bone_flow_graph.json'));caps=data(e01('bone_capacities.json'));bound=data(e01('bone_minimum.json'));net=collections.Counter()
 for e in graph['edges']:n=int(e['wei']);ck('Nonnegative graph capacity',n>=0);net[e['from']]-=n;net[e['to']]+=n
 for node,n in net.items():
  if node.startswith(('tx:','post:'))or node=='BEST_VAULT':ck('Model exact cash conservation '+node,n==0)
 applied=[]
 for s in graph['sources']:
  c=int(caps['other_cap_by_hash'].get(s['hash'],s['wei']));ck('OTHER capacity within retained source '+s['hash'],0<=c<=int(s['wei']));applied.append((s['node'],c))
 other=maxflow(graph['edges'],applied,graph['target']);target=int(graph['target_wei']);lower=target-other
 ck('Independent Dinic reproduces capped calculation',other==int(bound['maximum_OTHER_in_target_wei'])and lower==int(bound['minimum_tax_capital_in_target_wei']))
 unconstrained=maxflow(graph['edges'],[(s['node'],int(s['wei']))for s in graph['sources']],graph['target']);ck('Without attribution constraints forced tax is zero',unconstrained==target)
 flow=readcsv((P/'BONE_FLOW.csv').read_bytes());ck('Every original graph edge exported',len(flow)==len(graph['edges'])==455)
 for i,(a,b)in enumerate(zip(flow,graph['edges'])):ck('Exact edge export '+str(i+1),a['from_node']==b['from']and a['to_node']==b['to']and a['amount_wei']==b['wei']and a['kind']==b['kind']and int(a['edge_ordinal'])==i+1)
 transactions=readcsv((P/'BONE_TRANSACTIONS.csv').read_bytes());previous=0;receipt_gas_checks=0
 for t in transactions:
  before,inc,out,gas,after=[int(t[k])for k in ['before_wei','new_native_including_return_wei','native_out_net_of_change_wei','gas_wei','after_wei']]
  ck('Operator chronological balance '+t['hash'],before==previous and before+inc-out-gas==after and after>=0);previous=after
  path='originals/supplemental/phase12/operator/receipts/'+t['hash']+'.json'
  if path in originals and gas:
   d=data(path);d=json.loads(d['body'])if isinstance(d.get('body'),str)else d.get('body',d);r=d['result'];ck('Primary operator receipt gas '+t['hash'],int(r['gasUsed'],16)*int(r['effectiveGasPrice'],16)==gas);receipt_gas_checks+=1
 # Foundation: preserve all asset rows and avoid mixed-asset aggregation.
 foundation_bytes=(P/'FOUNDATION_LEDGER.csv').read_bytes();ck('Foundation ledger is an unchanged original copy',foundation_bytes==originals['originals/release/evidence/E12/reused/foundation_full_flow.csv'])
 f=readcsv(foundation_bytes);address='0xa819eaf3f1d79e03a6d1001818889655532a9150';dep=[x for x in f if x['asset']=='BNB'and x['direction']=='in'and x['to']==address];ordinary=[x for x in f if x['asset']=='BNB'and x['from']==address and x['classification']=='Foundation SOU-for-BNB Exchange-event payout'];withdraw=[x for x in f if x['asset']=='BNB'and x['from']==address and x['classification']=='owner/controller withdrawal from Foundation']
 a,b,c=[sum(int(x['raw_amount'])for x in v)for v in [dep,ordinary,withdraw]];fs=jfile('FOUNDATION_SUMMARY.json')
 ck('Foundation 18 deposits and complete 33-row ledger',len(dep)==18 and len(f)==33 and len(ordinary)==5 and len({x['to']for x in ordinary})==3 and len(withdraw)==1)
 ck('Foundation exact BNB reconciliation',a-b-c==0 and [a,b,c]==[int(fs[k])for k in ['deposit_total_wei','ordinary_exchange_total_wei','owner_bnb_withdrawal_total_wei']])
 funding=data('originals/release/evidence/E13/FOUNDATION_FUNDING_AND_CONTROL_EXECUTIONS.json');ck('Foundation funding table agrees with retained execution summary',int(funding['total_raw_bnb'])==a and funding['positive_bnb_deposits']==18)
 print(json.dumps({'status':'PASS','checks_passed':len(checks),'original_E01_logical_references':len(e01_index),'original_E01_unique_export_files':len({r['export_file']for r in e01_index}),'source_files_transport_verified':len(originals),'tax_count':len(tax),'beneficiary_total_wei':str(sums[0]),'platform_total_wei':str(sums[1]),'gross_total_wei':str(sums[2]),'bone_graph_edges':len(flow),'bone_transaction_epochs':len(transactions),'operator_primary_gas_checks':receipt_gas_checks,'bone_target_wei':str(target),'max_OTHER_wei':str(other),'conditional_minimum_tax_capital_wei':str(lower),'unconstrained_forced_tax_wei':str(target-unconstrained),'foundation_deposits':len(dep),'foundation_ledger_rows':len(f),'network_requests':0,'interpretation':'Integrity, decoding, chronology and model arithmetic checks only. Does not independently certify every graph omission, acquisition completeness, historical code assertion, alternative-funding ceiling or identity claim.'},indent=2))
if __name__=='__main__':main()
