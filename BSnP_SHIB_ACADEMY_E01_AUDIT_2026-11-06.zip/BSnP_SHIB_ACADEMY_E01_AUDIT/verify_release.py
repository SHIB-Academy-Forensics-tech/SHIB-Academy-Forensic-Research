"""BSnP public release verifier. Standard library only. No network or credentials."""
from pathlib import Path
import csv,gzip,hashlib,json,collections,sys,concurrent.futures
P=Path(__file__).resolve().parent
def hashfile(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def csvrows(p):
 with p.open(encoding='utf-8-sig',newline='')as f:return list(csv.DictReader(f))
def read(p):
 with p.open('rb')as f:payload=f.read()
 return json.loads(gzip.decompress(payload)if p.name.endswith('.gz')else payload)

def main():
 checks=[]
 def ck(name,value):
  if not value:raise AssertionError(name)
  checks.append(name)
 mf=csvrows(P/'MANIFEST_SHA256.csv')
 def manifest_ok(x):
  p=P/x['file'];return p.is_file()and p.stat().st_size==int(x['bytes'])and hashfile(p)==x['sha256']
 with concurrent.futures.ThreadPoolExecutor(max_workers=12)as pool:valid=list(pool.map(manifest_ok,mf))
 for x,ok in zip(mf,valid):ck('hash '+x['file'],ok)
 index=csvrows(P/'evidence/SOURCE_FILE_INDEX.csv');by={(x['source_group'],x['logical_source_path']):x for x in index}
 manifest_hashes={x['file']:x['sha256']for x in mf}
 def file(group,name):return P/by[(group,name)]['export_file']
 def data(group,name):return read(file(group,name))
 for x in index:ck('indexed export '+x['source_group']+'/'+x['logical_source_path'],x['export_file']in manifest_hashes and manifest_hashes[x['export_file']]==x['export_sha256'])
 tax=csvrows(file('E01','tax_distributions.csv'));ck('1934 distinct tax distributions',len(tax)==len({x['hash']for x in tax})==1934);totals=[0,0,0]
 for x in tax:
  r=data('E01','tax_receipts/'+x['hash']+'.json.gz')['result'];ck('primary payout receipt '+x['hash'],r['status']=='0x1'and r['transactionHash']==x['hash']and int(r['blockNumber'],16)==int(x['block']))
  amounts={}
  for l in r['logs']:
   if l['address'].lower()=='0x51db4cc6c47dd545b2328704ee5ca359c98f6f02'and len(l['data'])==130:amounts['0x'+l['data'][26:66]]=int(l['data'][66:],16)
  c,p,g=[int(x[k])for k in ['controller_wei','platform_wei','gross_wei']]
  ck('exact split '+x['hash'],amounts.get('0x0c6f72f394e968ee80c94727c381dada5fdcfce6')==c and amounts.get('0x8a08d98cbb218fceb318ecf3abc1ba43d8a7ab0e')==p and c+p==g and c==g*9000//10000)
  totals=[a+b for a,b in zip(totals,[c,p,g])]
 ck('Exact retained tax totals',totals==[111228693932512706818,12358743770279190376,123587437702791897194])
 splits=csvrows(file('E01','buyer_nine_allocations.csv'));ck('Nine early allocation sum',len(splits)==9 and sum(int(x['amount_raw'])for x in splits)==50376776419291692000000000)
 fees=csvrows(file('E01','octo_creator_fees.csv'));ck('OCTO controller fees',len(fees)==10 and sum(int(x['event_creatorFee_word4_wei'])for x in fees)==53478621363104934)
 def maxflow(edges,sources,target):
  names=sorted({e[k]for e in edges for k in ['from','to']}|{s[0]for s in sources}|{'SUPER',target});ix={n:i for i,n in enumerate(names)};g=[[]for _ in names]
  def add(a,b,n):
   u,v=ix[a],ix[b];g[u].append([v,n,len(g[v])]);g[v].append([u,0,len(g[u])-1])
  for e in edges:add(e['from'],e['to'],int(e['wei']))
  for n,c in sources:add('SUPER',n,c)
  out=0
  while True:
   parent={ix['SUPER']:None};q=collections.deque([ix['SUPER']])
   while q and ix[target]not in parent:
    u=q.popleft()
    for j,(v,c,_)in enumerate(g[u]):
     if c and v not in parent:parent[v]=(u,j);q.append(v)
   if ix[target]not in parent:return out
   v=ix[target];amount=10**60
   while parent[v]is not None:u,j=parent[v];amount=min(amount,g[u][j][1]);v=u
   v=ix[target]
   while parent[v]is not None:u,j=parent[v];e=g[u][j];e[1]-=amount;g[v][e[2]][1]+=amount;v=u
   out+=amount
 graph=data('E01','bone_flow_graph.json');bound=data('E01','bone_minimum.json');caps=data('E01','bone_capacities.json')['other_cap_by_hash'];sources=[]
 for s in graph['sources']:
  c=int(caps.get(s['hash'],s['wei']));ck('Source capacity '+s['hash'],0<=c<=int(s['wei']));sources.append((s['node'],c))
 minimum=int(graph['target_wei'])-maxflow(graph['edges'],sources,'TARGET');ck('Joint economic BONE lower bound',minimum==int(bound['minimum_tax_capital_in_target_wei'])==538363265919498596698263)
 ck('Original bound input hash linkage',by[('E01','bone_flow_graph.json')]['source_sha256']==bound['graph_SHA256']and by[('E01','bone_capacities.json')]['source_sha256']==bound['input_SHA256'])
 buy=data('E12','DIRECT_BUY_PURCHASE_CONCENTRATION.json');ck('Direct helper call sum',sum(int(x['count'])for x in buy['buyers'])==buy['successful_purchases']==3587);ck('Direct helper pass-through',sum(int(x['raw_bnb'])for x in buy['buyers'])==int(buy['total_raw_bnb'])==int(buy['same_value_sent_to_pancakeswap_raw']))
 booster=data('E12','PRIMARY_GENERATED_HOLDER_TRANSFERS.json');ck('Generated address records',len(booster)==len({x['address']for x in booster})==10800 and sum(int(x['amount_raw'])for x in booster)==54*10**18)
 cash=data('E13','CONTROLLER_NATIVE_CASH_CLOSED.json');ck('Controller native cash identity',cash['primary_nonces_complete']and cash['closed']and int(cash['incoming_raw'])-int(cash['successful_outgoing_raw'])-int(cash['primary_gas_raw'])==int(cash['balance_raw']))
 endpoint=data('E13','ENDPOINT_NATIVE_CASH_CLOSED.json');ck('Endpoint native cash identity',endpoint['closed']and int(endpoint['incoming_raw'])-int(endpoint['outgoing_raw'])-int(endpoint['gas_raw'])==int(endpoint['balance_raw']))
 wh=data('E13','WHITELIST_SIGNED_HISTORY_CLOSURE.json');ck('Closed whitelist history',wh['signed_nonces']==list(range(9))and wh['foundation_calls']==0)
 content=read(P/'REPORT_CONTENT.json');ck('54 registered entries',len(content['projects'])==54 and {x['number']for x in content['projects']}==set(range(1,55)));ck('17 group profiles',len(content['groups'])==17)
 pages=read(P/'REPORT_PAGE_MAP.json');ck('Article reference map',pages['tax']==7 and pages['bone']==8 and pages['foundation']==9 and pages['purchases']==12 and pages['clusters']==16)
 new=data('E16','RAGNAR_RECENT_ACTIVITY_FINDINGS.json');obs={x['id']:x for x in new['observations']}
 ck('Original current Ragnar mention timestamp',obs['RAG-CURRENT-01']['post_utc']=='2026-11-02T13:05:21.000Z')
 ck('Host role kept distinct from payment',obs['RAG-CURRENT-03']['status']=='VERIFIED_PUBLIC_POST_AND_DISPLAYED_HOST_ROLE'and 'compensation'in obs['RAG-CURRENT-03']['limits'])
 ck('No proved Ragnar beneficiary wallet claimed','No authenticated personal beneficiary wallet'in new['financial_result'])
 official=data('E17','OFFICIAL_PROJECT_DELIVERY_AND_ACCOUNTABILITY.json');ck('13 official product categories remain open',len(official['projects'])==13 and all('OPEN'in x['financial_and_delivery_audit_status']for x in official['projects']))
 ck('Official chain checkpoint is chain 109',official['network'][0]['chain_id_hex']=='0x6d')
 ck('Revised article page map',pages['ragnar_activity']==24 and pages['ragnar_delivery']==25 and pages['official_products']==27 and pages['reading_conclusions']==31)
 brand=data('E18','BRANDING_PRIMARY_POST_OBSERVATIONS.json');bp={r['id']:r for r in brand['posts']}
 ck('Original Totem product promotion date',bp['R21-P02']['post_utc']=='2026-10-16T09:40:46.000Z')
 ck('Original WIFH network promotion date',bp['R21-P03']['post_utc']=='2026-10-08T12:05:05.000Z')
 matrix=data('E18','SHIB_BRANDING_PROMOTION_BENEFIT_MATRIX.json')['rows'];ck('Promotion compensation remains unverified',len(matrix)==4 and all(r['personal_payment']=='UNVERIFIED'for r in matrix))
 ck('Benefit and governance page map',pages['brand_benefit']==32 and pages['community_direction']==36)
 content=read(P/'REPORT_CONTENT.json');chap={c['key']:c for c in content['chapters']};brief=read(P/'FEATURE_CONTENT.json');bt=' '.join(t for k,t in brief)
 ck('Unrelated Totem case excluded','totem_receipts'not in chap and '6.6968'not in bt)
 ck('Cross-chain visibility and Shibarium return','other blockchain communities'in bt and 'reason to discover and use the network'in bt)
 ck('Constructive closing retained','easier onboarding'in bt and 'Every contribution can help'in bt and 'one useful step at a time'in bt)
 ck('First person narrative',all('BSnP'not in t for k,t in brief if k=='body')and 'I examine what happened'in bt)
 ck('Acceptability left to the community','is for the community to decide'in ' '.join(chap['brand_benefit']['paragraphs']))
 ck('Publisher unacceptable verdict removed','ethically unacceptable'not in bt+' '.join(' '.join(c['paragraphs'])for c in content['chapters']))
 ck('Plain unknown-payment language','Whether he was paid for these promotions is unknown'in bt)
 ck('Ragnar contributions lead the profile',next(t for k,t in brief if k=='body'and t.startswith('Ragnar:')).startswith('Ragnar: his public contribution statement'))
 ck('Supported operational cluster language','point to a common operating group or entity'in bt)
 ck('21 publication source groups',len(content['source_groups'])==21)
 social=data('E19','FINDINGS.json');notes=data('E20','FINDINGS.json');n={r['id']:r for r in notes}
 ck('New research observations',len(social['observations'])==6 and len(notes)==14)
 ck('Rename attribution correction',n['S09']['status']=='CONTRADICTED'and 'Someone Smart'in n['S09']['observation'])
 ck('Paid takeover not upgraded to fact',n['S10']['status']=='UNVERIFIED'and n['F02']['status']=='UNVERIFIED')
 ck('FHE directories checked',n['F04']['status']=='VERIFIED')
 for name in ['fhe_zama_chains','fhe_zama_addresses']:
  access=data('E20','raw/'+name+'.access.json')
  with file('E20','raw/'+name+'.body.gz').open('rb')as f:stored=f.read()
  raw=gzip.decompress(stored)
  ck('Raw public source hash '+name,hashlib.sha256(stored).hexdigest()==access['raw_sha256']and access['status']==200)
  ck('Shibarium absent in bounded directory '+name,b'Shibarium'not in raw)
 for name,expected in [('group_rename_photo1.jpg','60eebe12138ae03fbef16c8f6d9267e345165d366ceced723ebf3fb5ac2ae626'),('group_rename_photo2.jpg','2b607486f2794cc983928f47aeb5a155b43fa38f22d096f974b9b768d275a29f')]:ck('Public original image '+name,hashfile(file('E19','raw/'+name))==expected)
 ck('New chapters in stable page map',pages['social_control']==15 and pages['zama_fhe']==28 and pages['control_rights']==14)
 ctrl=data('E21','CONTROL_CHECKS.json');ck('Recovered April digest and May decoded continuity',ctrl['april_body_matches_prior_cdx_digest']and ctrl['may_decoded_body_identical']and ctrl['all_six_feature_modules_recovered'])
 cf=data('E21','FINDINGS.json');ck('New actor findings bounded',len(cf)==10 and cf[-1]['status']=='UNVERIFIED')
 ck('Separate-site motive and conflicting origin accounts retained',any(x['id']=='CTRL24-02'for x in cf)and any(x['id']=='CTRL24-01'for x in cf))
 ck('Ragnar is a community figure in revised brief','formal SHIB employment relationship is not established here'in bt and 'his focus appears mainly to be other tokens'in bt)

 print('PASS:',len(checks),'integrity and record/arithmetic checks;',len(mf),'manifest files;',len(index),'source records. No network used.')
 return 0
# Optional archive reader allows verification without extracting 40,000 small files.
class ArchivePath:
 def __init__(self,z,key):self.z=z;self.key=key
 def __truediv__(self,part):return ArchivePath(self.z,self.key.rstrip('/')+'/'+str(part))
 @property
 def name(self):return self.key.rsplit('/',1)[-1]
 def is_file(self):
  try:return not self.z.getinfo(self.key).is_dir()
  except KeyError:return False
 def stat(self):
  from types import SimpleNamespace
  return SimpleNamespace(st_size=self.z.getinfo(self.key).file_size)
 def open(self,mode='r',encoding=None,newline=None):
  import io
  payload=io.BytesIO(self.z.read(self.key))
  return payload if 'b'in mode else io.TextIOWrapper(payload,encoding=encoding or'utf-8',newline=newline)
if __name__=='__main__':
 if len(sys.argv)==3 and sys.argv[1]=='--archive':
  import zipfile
  archive=zipfile.ZipFile(sys.argv[2]);prefix=next(n.rsplit('/',1)[0]for n in archive.namelist()if n.endswith('/MANIFEST_SHA256.csv')and n.count('/')==1);P=ArchivePath(archive,prefix)
 raise SystemExit(main())
