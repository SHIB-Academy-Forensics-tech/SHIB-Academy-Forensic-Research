"""Run retained original arithmetic checkers in a disposable copy. No network."""
from pathlib import Path
import tempfile,shutil,subprocess,sys,json
p=Path(__file__).resolve().parent/'originals/supplemental/phase13/bounds'
if not p.is_dir():raise SystemExit('First run python verify_e01.py --materialize')
with tempfile.TemporaryDirectory(prefix='bsnp_bone_audit_')as d:
 q=Path(d)/'bounds';shutil.copytree(p,q)
 for name in ['bound_target.py','verify_bounds.py']:
  subprocess.run([sys.executable,str(q/name)],check=True,cwd=q)
 result=json.loads((q/'RESULT.json').read_text())
 print(json.dumps({'original_arithmetic_scripts':'PASS','minimum_tax_capital_in_target_wei':result['minimum_tax_capital_in_target_wei'],'originals_modified':False,'interpretation':'Checks the retained arithmetic inputs; not a new acquisition or a complete audit of all source-cap premises.'},indent=2))
